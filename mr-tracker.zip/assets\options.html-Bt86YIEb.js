import{r as $,a as h,b as C,c as a,i as S}from"./theme-DgVcF6zp.js";import{c as w,b as g,g as A}from"./storage-VRRFTfch.js";import{g as k}from"./registry-B1WIMShi.js";const q=$("config-form"),p=h("accounts"),E=h("accounts-empty"),M=h("add-account"),L=C("new-provider"),r=h("save-status"),_=[{value:"assigned_to_me",label:"Assigned to me"},{value:"created_by_me",label:"Created by me"},{value:"needs_my_review",label:"Needs my review"},{value:"all",label:"All I'm involved in"}],I=["open","merged","closed"];let l=[];async function O(){const e=await A();S({selectId:"theme-select",toggleId:"mode-toggle",theme:e.theme,mode:e.mode,onChange:(s,o)=>void g({theme:s,mode:o})}),l=e.accounts,a("syncIntervalMinutes").value=String(e.syncIntervalMinutes),a("notifyNewMr").checked=e.notifyOn.newMr,a("notifyStatusChange").checked=e.notifyOn.statusChange,a("dispThemeControls").checked=e.display.themeControls,a("dispFilters").checked=e.display.filters,a("dispSort").checked=e.display.sort,a("dispOpenAll").checked=e.display.openAll,a("dispCredit").checked=e.display.credit,v()}function v(){E.hidden=l.length>0,p.replaceChildren();for(const e of l)p.insertAdjacentHTML("beforeend",T(e))}function T(e){const s=k(e.provider),o=s.fields.map(t=>{const u=e[t.key]??"";return`
        <label class="field-label">
          ${t.label}${t.required?" *":""}
          <input
            class="input"
            type="${t.secret?"password":"text"}"
            data-field="${t.key}"
            autocomplete="off"
            placeholder="${c(t.placeholder)}"
            value="${c(u)}"
          />
          ${t.hint?`<span class="hint">${c(t.hint)}</span>`:""}
        </label>`}).join(""),n=_.map(t=>`<option value="${t.value}"${e.scope===t.value?" selected":""}>${t.label}</option>`).join(""),i=I.map(t=>`
      <label class="check-row">
        <input type="checkbox" data-state="${t}"${e.states.includes(t)?" checked":""} />
        ${t}
      </label>`).join("");return`
    <div class="account-card card" data-id="${c(e.id)}">
      <div class="account-head">
        <div class="account-title">
          <input class="account-color" type="color" data-field="color" value="${c(e.color)}" title="Account color" />
          <span class="badge provider-${e.provider}">${c(s.label)}</span>
          <input class="input account-label" data-field="label" value="${c(e.label)}" placeholder="Label" />
        </div>
        <div class="account-head-actions">
          <label class="check-row">
            <input type="checkbox" data-field="enabled"${e.enabled?" checked":""} /> Enabled
          </label>
          <button type="button" class="btn btn-sm" data-remove="${c(e.id)}">Remove</button>
        </div>
      </div>
      ${o}
      <p class="hint">
        <a href="${c(s.tokenDocsUrl)}" target="_blank" rel="noopener">How to create a read-only token</a>
      </p>
      <div class="account-filters">
        <label class="field-label">
          Scope
          <select class="select" data-field="scope">${n}</select>
        </label>
        <div>
          <p class="hint">States:</p>
          <div class="checks">${i}</div>
        </div>
      </div>
    </div>`}function m(){return Array.from(p.querySelectorAll(".account-card")).map(s=>{var f,b;const o=s.dataset.id??"",n=l.find(d=>d.id===o),i=(n==null?void 0:n.provider)??"gitlab",t=d=>{var y;return((y=s.querySelector(`[data-field="${d}"]`))==null?void 0:y.value.trim())??""},u=Array.from(s.querySelectorAll("input[data-state]:checked")).map(d=>d.dataset.state);return{id:o,provider:i,label:t("label")||i,host:t("host"),token:t("token"),username:t("username"),workspace:t("workspace"),scope:((f=s.querySelector('[data-field="scope"]'))==null?void 0:f.value)??"assigned_to_me",states:u.length?u:["open"],enabled:((b=s.querySelector('[data-field="enabled"]'))==null?void 0:b.checked)??!0,color:t("color")||(n==null?void 0:n.color)||"#e8590c"}})}M.addEventListener("click",()=>{const e=L.value;l=m(),l.push(w(e,k(e).label,l.length)),v()});p.addEventListener("click",e=>{const o=e.target.dataset.remove;o&&(l=m().filter(n=>n.id!==o),v())});q.addEventListener("submit",e=>{e.preventDefault(),N()});async function N(){r.textContent="Saving…",r.classList.remove("error");const e=m(),s=e.find(n=>n.enabled&&!n.token);if(s){r.textContent=`"${s.label}" needs a token.`,r.classList.add("error");return}const o=await P(e);if(await g({accounts:e,syncIntervalMinutes:Number(a("syncIntervalMinutes").value),notifyOn:{newMr:a("notifyNewMr").checked,statusChange:a("notifyStatusChange").checked,newComment:!1},display:{themeControls:a("dispThemeControls").checked,filters:a("dispFilters").checked,sort:a("dispSort").checked,openAll:a("dispOpenAll").checked,credit:a("dispCredit").checked}}),l=e,await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!o){r.textContent="Saved, but self-hosted host access was denied.",r.classList.add("error");return}r.textContent="Saved. Background sync updated.",setTimeout(()=>{r.textContent=""},3e3)}function x(e){try{const s=new URL(e);return`${s.protocol}//${s.host}/*`}catch{return null}}async function P(e){const s=new Set;for(const n of e){if(!n.enabled)continue;const i=n.host.trim();if(!i)continue;const t=x(i);t&&s.add(t)}if(!s.size)return!0;const o=[...s];return await chrome.permissions.contains({origins:o})?!0:chrome.permissions.request({origins:o})}function c(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}O();
//# sourceMappingURL=options.html-Bt86YIEb.js.map
