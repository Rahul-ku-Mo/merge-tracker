import{r as k,a as v,b as $,c as i}from"./dom-Cy7q98ik.js";import{c as S,b as w,g as C}from"./storage-DTn6t9Je.js";import{g as y}from"./registry-DTnsLLsK.js";const q=k("config-form"),p=v("accounts"),E=v("accounts-empty"),A=v("add-account"),M=$("new-provider"),o=v("save-status"),L=[{value:"assigned_to_me",label:"Assigned to me"},{value:"created_by_me",label:"Created by me"},{value:"all",label:"All I'm involved in"}],_=["open","merged","closed"];let r=[];async function x(){const e=await C();r=e.accounts,i("syncIntervalMinutes").value=String(e.syncIntervalMinutes),i("notifyNewMr").checked=e.notifyOn.newMr,i("notifyStatusChange").checked=e.notifyOn.statusChange,f()}function f(){E.hidden=r.length>0,p.replaceChildren();for(const e of r)p.insertAdjacentHTML("beforeend",I(e))}function I(e){const n=y(e.provider),s=n.fields.map(t=>{const u=e[t.key]??"";return`
        <label class="field-label">
          ${t.label}${t.required?" *":""}
          <input
            class="input"
            type="${t.secret?"password":"text"}"
            data-field="${t.key}"
            autocomplete="off"
            placeholder="${c(t.placeholder)}"
            value="${c(u)}"
          />
          ${t.hint?`<span class="hint">${c(t.hint)}</span>`:""}
        </label>`}).join(""),a=L.map(t=>`<option value="${t.value}"${e.scope===t.value?" selected":""}>${t.label}</option>`).join(""),l=_.map(t=>`
      <label class="check-row">
        <input type="checkbox" data-state="${t}"${e.states.includes(t)?" checked":""} />
        ${t}
      </label>`).join("");return`
    <div class="account-card card" data-id="${c(e.id)}">
      <div class="account-head">
        <div class="account-title">
          <span class="badge provider-${e.provider}">${c(n.label)}</span>
          <input class="input account-label" data-field="label" value="${c(e.label)}" placeholder="Label" />
        </div>
        <div class="account-head-actions">
          <label class="check-row">
            <input type="checkbox" data-field="enabled"${e.enabled?" checked":""} /> Enabled
          </label>
          <button type="button" class="btn btn-sm" data-remove="${c(e.id)}">Remove</button>
        </div>
      </div>
      ${s}
      <p class="hint">
        <a href="${c(n.tokenDocsUrl)}" target="_blank" rel="noopener">How to create a read-only token</a>
      </p>
      <div class="account-filters">
        <label class="field-label">
          Scope
          <select class="select" data-field="scope">${a}</select>
        </label>
        <div>
          <p class="hint">States:</p>
          <div class="checks">${l}</div>
        </div>
      </div>
    </div>`}function m(){return Array.from(p.querySelectorAll(".account-card")).map(n=>{var b,h;const s=n.dataset.id??"",a=r.find(d=>d.id===s),l=(a==null?void 0:a.provider)??"gitlab",t=d=>{var g;return((g=n.querySelector(`[data-field="${d}"]`))==null?void 0:g.value.trim())??""},u=Array.from(n.querySelectorAll("input[data-state]:checked")).map(d=>d.dataset.state);return{id:s,provider:l,label:t("label")||l,host:t("host"),token:t("token"),username:t("username"),workspace:t("workspace"),scope:((b=n.querySelector('[data-field="scope"]'))==null?void 0:b.value)??"assigned_to_me",states:u.length?u:["open"],enabled:((h=n.querySelector('[data-field="enabled"]'))==null?void 0:h.checked)??!0}})}A.addEventListener("click",()=>{const e=M.value;r=m(),r.push(S(e,y(e).label)),f()});p.addEventListener("click",e=>{const s=e.target.dataset.remove;s&&(r=m().filter(a=>a.id!==s),f())});q.addEventListener("submit",e=>{e.preventDefault(),O()});async function O(){o.textContent="Saving…",o.classList.remove("error");const e=m(),n=e.find(a=>a.enabled&&!a.token);if(n){o.textContent=`"${n.label}" needs a token.`,o.classList.add("error");return}const s=await P(e);if(await w({accounts:e,syncIntervalMinutes:Number(i("syncIntervalMinutes").value),notifyOn:{newMr:i("notifyNewMr").checked,statusChange:i("notifyStatusChange").checked,newComment:!1}}),r=e,await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!s){o.textContent="Saved, but self-hosted host access was denied.",o.classList.add("error");return}o.textContent="Saved. Background sync updated.",setTimeout(()=>{o.textContent=""},3e3)}function N(e){try{const n=new URL(e);return`${n.protocol}//${n.host}/*`}catch{return null}}async function P(e){const n=new Set;for(const a of e){if(!a.enabled)continue;const l=a.host.trim();if(!l)continue;const t=N(l);t&&n.add(t)}if(!n.size)return!0;const s=[...n];return await chrome.permissions.contains({origins:s})?!0:chrome.permissions.request({origins:s})}function c(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}x();
//# sourceMappingURL=options.html-DIc_OQog.js.map
