import{a as r}from"./dom-Cy7q98ik.js";import{a as p,g as m}from"./storage-DTn6t9Je.js";const a=r("status"),i=r("mr-list"),c=r("empty-state"),l=r("sync-btn"),g=r("last-sync"),h=r("options-link");h.addEventListener("click",t=>{t.preventDefault(),chrome.runtime.openOptionsPage()});l.addEventListener("click",()=>void f(!0));async function y(){if(!(await m()).accounts.some(s=>s.enabled&&s.token.trim())){n("Add an account in Settings to get started.","error"),i.hidden=!0,c.hidden=!0;return}await d(),await f(!1)}async function d(){const{mergeRequests:t,lastSyncAt:e}=await p();t.length?(n(`${t.length} request${t.length===1?"":"s"}`,"success"),$(t),i.hidden=!1,c.hidden=!0):(n("No merge requests yet. Click Sync.","default"),i.hidden=!0,c.hidden=!1),g.textContent=e?`Synced ${w(e)}`:""}function $(t){i.replaceChildren();for(const e of t){const s=document.createElement("li");s.className="mr-item",s.innerHTML=`
      <a class="mr-title" href="${o(e.url)}" target="_blank" rel="noopener">${o(e.title)}</a>
      <span class="mr-meta">
        <span class="badge provider-${e.provider}">${e.provider}</span>
        <span class="mr-meta-sep">·</span>
        <span class="badge ${e.state}">${e.state}</span>
        <span class="mr-meta-sep">·</span>
        <span>${o(e.repo)}#${e.number}</span>
        <span class="mr-meta-sep">·</span>
        <span>${o(e.author)}</span>
      </span>
    `,i.appendChild(s)}}async function f(t){l.disabled=!0,n("Syncing…","loading");try{const e=await chrome.runtime.sendMessage({type:"SYNC_NOW"});if(!(e!=null&&e.ok))throw new Error((e==null?void 0:e.error)??"Sync failed");await d(),e.errors.length?n(`${e.count} request(s) · ${e.errors.length} account(s) failed`,"error"):e.notified>0&&n(`${e.count} request(s) · ${e.notified} notification(s)`,"success")}catch(e){if(t){const s=e instanceof Error?e.message:String(e);n(s,"error")}else await d()}finally{l.disabled=!1}}function n(t,e="default"){a.textContent=t,a.hidden=!1,a.classList.remove("is-error","is-success","is-loading"),e==="error"&&a.classList.add("is-error"),e==="success"&&a.classList.add("is-success"),e==="loading"&&a.classList.add("is-loading")}function w(t){const e=Date.now()-new Date(t).getTime(),s=Math.floor(e/6e4);if(s<1)return"just now";if(s<60)return`${s}m ago`;const u=Math.floor(s/60);return u<24?`${u}h ago`:new Date(t).toLocaleString()}function o(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}y();
//# sourceMappingURL=popup.html-6QZHkIHY.js.map
