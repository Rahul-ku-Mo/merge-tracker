import{r as F,a as k,b,e as P,c,n as B,h as H,i as x,p as D}from"./permissions-B0ed5VxG.js";import{t as l,f as U,g as $,h as _,n as j,P as y,A as W,F as M,i as N,j as Y,a as z,k as K,e as G,l as J,o as Q,R as V}from"./registry-vJOnLC0M.js";const X=F("config-form"),m=k("accounts"),Z=k("accounts-empty"),ee=k("add-account"),te=b("new-provider"),v=k("save-status"),ne=[{value:"assigned_to_me",label:l("scopeAssigned")},{value:"created_by_me",label:l("scopeCreated")},{value:"needs_my_review",label:l("scopeReview")},{value:"all",label:l("scopeAll")}],se=["open","merged","closed"];let u=[],d=[];const h=new Set,ae={needs:"tabNeeds",mine:"tabMine",reviewing:"tabReviewing",all:"tabAll",recent:"tabRecent"};async function oe(){Y(),H();const e=await z();x({toggleId:"mode-toggle",mode:e.mode,onChange:t=>void _({mode:t})}),u=e.accounts,c("syncIntervalMinutes").value=String(e.syncIntervalMinutes),c("notifyNewMr").checked=e.notifyOn.newMr,c("notifyStatusChange").checked=e.notifyOn.statusChange,c("notifyReviewRequested").checked=e.notifyOn.reviewRequested,c("notifyCiFailed").checked=e.notifyOn.ciFailed,c("notifyDigest").checked=e.digestNotifications,c("quietEnabled").checked=e.quietHours.enabled,c("ticketBaseUrl").value=e.ticketBaseUrl,c("quietStart").value=String(e.quietHours.start),c("quietEnd").value=String(e.quietHours.end),c("dispThemeControls").checked=e.display.themeControls,c("dispFilters").checked=e.display.filters,c("dispSort").checked=e.display.sort,c("dispOpenAll").checked=e.display.openAll,c("dispCredit").checked=e.display.credit,ie(e.profile),S(K(e.profile??M,e.tabs)),re(e.recentRetentionDays),L()}function E(){const e=b("profile").value;return N(e)?e:M}function ce(e){return l(y[E()].tabLabels[e]??ae[e])}function S(e){d=[...e,...W.filter(t=>!e.includes(t))],h.clear();for(const t of e)h.add(t);w()}function w(){k("tabs-list").replaceChildren(...d.map((t,n)=>{const s=ce(t),o=document.createElement("li"),a=document.createElement("label");a.className="check-row";const i=document.createElement("input");i.type="checkbox",i.checked=h.has(t),i.disabled=i.checked&&h.size===1,i.addEventListener("change",()=>{i.checked?h.add(t):h.delete(t),w()});const p=document.createElement("span");return p.textContent=s,a.append(i,p),o.append(a,R("↑",l("tabsMoveUp",s),n===0,()=>T(n,-1))),o.append(R("↓",l("tabsMoveDown",s),n===d.length-1,()=>T(n,1))),o}))}function R(e,t,n,s){const o=document.createElement("button");return o.type="button",o.className="btn btn-ghost move",o.textContent=e,o.title=t,o.setAttribute("aria-label",t),o.disabled=n,o.addEventListener("click",()=>s()),o}function T(e,t){const n=e+t;n<0||n>=d.length||([d[e],d[n]]=[d[n],d[e]],w())}function le(){const e=d.filter(n=>h.has(n)),t=y[E()].tabs;return e.length===t.length&&e.every((n,s)=>n===t[s])?null:e}function ie(e){const t=b("profile"),n=J.map(s=>{const o=document.createElement("option");return o.value=s,o.textContent=l(Q[s]),o.selected=s===e,o});if(!e){const s=document.createElement("option");s.value="",s.textContent=l("profileUnset"),s.selected=!0,n.unshift(s)}t.replaceChildren(...n)}function re(e){b("recentRetention").replaceChildren(...V.map(n=>{const s=document.createElement("option");return s.value=String(n),s.textContent=n===1?l("dayOne"):l("daysMany",String(n)),s.selected=n===e,s}))}function L(){Z.hidden=u.length>0,m.replaceChildren();for(const e of u)m.insertAdjacentHTML("beforeend",de(e));m.querySelectorAll(".account-card").forEach(e=>{I(e)})}function C(e,t){return['<option value="">N/A</option>',...(t&&!e.includes(t)?[t,...e]:e).map(o=>`<option value="${r(o)}"${o===t?" selected":""}>${r(o)}</option>`)].join("")}async function I(e){var p,g;const t=$(e.dataset.provider),n=e.querySelector('select[data-field="workspace"]'),s=e.querySelector(".org-status"),o=((p=e.querySelector('[data-field="token"]'))==null?void 0:p.value.trim())??"",a=((g=e.querySelector('[data-field="host"]'))==null?void 0:g.value.trim())??"";if(!n||!t.listWorkspaces||!o)return;const i=n.value;n.disabled=!0;try{const f=await t.listWorkspaces(o,a);n.innerHTML=C(f,i),s&&(s.textContent="")}catch{n.innerHTML=C([],i),s&&(s.textContent=l("orgLoadFailed"))}finally{n.disabled=!1}}m.addEventListener("change",e=>{const t=e.target;if(t.dataset.field==="token"||t.dataset.field==="host"){const n=t.closest(".account-card");n&&I(n)}});function de(e){const t=$(e.provider),n=t.fields.map(a=>{const i=e[a.key]??"";return a.kind==="select"?`
        <label class="field-label">
          ${a.label}
          <select class="select" data-field="${a.key}">${C([],i)}</select>
          <span class="hint org-status"></span>
          ${a.hint?`<span class="hint">${r(a.hint)}</span>`:""}
        </label>`:`
        <label class="field-label">
          ${a.label}${a.required?" *":""}
          <input
            class="input"
            type="${a.secret?"password":"text"}"
            data-field="${a.key}"
            autocomplete="off"
            placeholder="${r(a.placeholder)}"
            value="${r(i)}"
          />
          ${a.hint?`<span class="hint">${r(a.hint)}</span>`:""}
        </label>`}).join(""),s=ne.map(a=>`<option value="${a.value}"${e.scope===a.value?" selected":""}>${a.label}</option>`).join(""),o=se.map(a=>`
      <label class="check-row">
        <input type="checkbox" data-state="${a}"${e.states.includes(a)?" checked":""} />
        ${G(a)}
      </label>`).join("");return`
    <div class="account-card card" data-id="${r(e.id)}" data-provider="${e.provider}">
      <div class="account-head">
        <div class="account-title">
          <span class="badge provider-${e.provider}" title="${r(t.label)}">${D(e.provider)}</span>
          <input class="input account-label" data-field="label" value="${r(e.label)}" placeholder="${l("labelPlaceholder")}" />
        </div>
        <div class="account-head-actions">
          <label class="check-row">
            <input type="checkbox" data-field="enabled"${e.enabled?" checked":""} /> ${l("enabled")}
          </label>
          <button type="button" class="btn btn-sm" data-remove="${r(e.id)}">${l("remove")}</button>
        </div>
      </div>
      ${n}
      <p class="hint">
        <a href="${r(t.tokenDocsUrl)}" target="_blank" rel="noopener">${l("tokenHowTo")}</a>
      </p>
      <div class="account-filters">
        <label class="field-label">
          ${l("scope")}
          <select class="select" data-field="scope">${s}</select>
        </label>
        <div>
          <p class="hint">${l("statesLabel")}</p>
          <div class="checks">${o}</div>
        </div>
      </div>
    </div>`}function q(){return Array.from(m.querySelectorAll(".account-card")).map(t=>{var p,g;const n=t.dataset.id??"",s=u.find(f=>f.id===n),o=(s==null?void 0:s.provider)??"gitlab",a=f=>{var A;return((A=t.querySelector(`[data-field="${f}"]`))==null?void 0:A.value.trim())??""},i=Array.from(t.querySelectorAll("input[data-state]:checked")).map(f=>f.dataset.state);return{id:n,provider:o,label:a("label")||o,host:a("host"),token:a("token"),username:a("username"),workspace:a("workspace"),scope:((p=t.querySelector('[data-field="scope"]'))==null?void 0:p.value)??"assigned_to_me",states:i.length?i:["open"],enabled:((g=t.querySelector('[data-field="enabled"]'))==null?void 0:g.checked)??!0,color:(s==null?void 0:s.color)||"#e8590c"}})}ee.addEventListener("click",()=>{const e=te.value;u=q(),u.push(U(e,$(e).label,u.length)),L()});m.addEventListener("click",e=>{const n=e.target.dataset.remove;n&&(u=q().filter(s=>s.id!==n),L())});X.addEventListener("submit",e=>{e.preventDefault(),ue()});async function ue(){v.textContent=l("saving"),v.classList.remove("error");const e=q(),t=e.find(o=>o.enabled&&!o.token);if(t){v.textContent=l("needsToken",t.label),v.classList.add("error");return}const n=await P(e),s=b("profile").value;if(await _({accounts:e,...N(s)?{profile:s}:{},tabs:le(),syncIntervalMinutes:Number(c("syncIntervalMinutes").value),notifyOn:{newMr:c("notifyNewMr").checked,statusChange:c("notifyStatusChange").checked,newComment:!1,reviewRequested:c("notifyReviewRequested").checked,ciFailed:c("notifyCiFailed").checked},digestNotifications:c("notifyDigest").checked,ticketBaseUrl:B(c("ticketBaseUrl").value),quietHours:{enabled:c("quietEnabled").checked,start:O(Number(c("quietStart").value)),end:O(Number(c("quietEnd").value))},display:{themeControls:c("dispThemeControls").checked,filters:c("dispFilters").checked,sort:c("dispSort").checked,openAll:c("dispOpenAll").checked,credit:c("dispCredit").checked},recentRetentionDays:j(Number(b("recentRetention").value))}),u=e,await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!n){v.textContent=l("hostAccessDenied"),v.classList.add("error");return}v.textContent=l("saved"),setTimeout(()=>{v.textContent=""},3e3)}function r(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}b("profile").addEventListener("change",()=>S(y[E()].tabs));k("tabs-reset").addEventListener("click",()=>S(y[E()].tabs));oe();function O(e){return Number.isInteger(e)&&e>=0&&e<=23?e:0}
//# sourceMappingURL=options.html-CzY20z4h.js.map
