import{r as C,a as h,b as w,e as S,c as a,h as A,i as M}from"./permissions-D7RsSpsT.js";import{t as s,d as E,b as g,e as $,f as q,g as L,c as _}from"./registry-CixNjWm-.js";const I=C("config-form"),v=h("accounts"),O=h("accounts-empty"),T=h("add-account"),x=w("new-provider"),d=h("save-status"),N=[{value:"assigned_to_me",label:s("scopeAssigned")},{value:"created_by_me",label:s("scopeCreated")},{value:"needs_my_review",label:s("scopeReview")},{value:"all",label:s("scopeAll")}],P=["open","merged","closed"];let r=[];async function j(){q(),A();const e=await L();M({toggleId:"mode-toggle",mode:e.mode,onChange:o=>void $({mode:o})}),r=e.accounts,a("syncIntervalMinutes").value=String(e.syncIntervalMinutes),a("notifyNewMr").checked=e.notifyOn.newMr,a("notifyStatusChange").checked=e.notifyOn.statusChange,a("dispThemeControls").checked=e.display.themeControls,a("dispFilters").checked=e.display.filters,a("dispSort").checked=e.display.sort,a("dispOpenAll").checked=e.display.openAll,a("dispCredit").checked=e.display.credit,b()}function b(){O.hidden=r.length>0,v.replaceChildren();for(const e of r)v.insertAdjacentHTML("beforeend",D(e))}function D(e){const o=g(e.provider),l=o.fields.map(t=>{const u=e[t.key]??"";return`
        <label class="field-label">
          ${t.label}${t.required?" *":""}
          <input
            class="input"
            type="${t.secret?"password":"text"}"
            data-field="${t.key}"
            autocomplete="off"
            placeholder="${n(t.placeholder)}"
            value="${n(u)}"
          />
          ${t.hint?`<span class="hint">${n(t.hint)}</span>`:""}
        </label>`}).join(""),c=N.map(t=>`<option value="${t.value}"${e.scope===t.value?" selected":""}>${t.label}</option>`).join(""),p=P.map(t=>`
      <label class="check-row">
        <input type="checkbox" data-state="${t}"${e.states.includes(t)?" checked":""} />
        ${_(t)}
      </label>`).join("");return`
    <div class="account-card card" data-id="${n(e.id)}">
      <div class="account-head">
        <div class="account-title">
          <input class="account-color" type="color" data-field="color" value="${n(e.color)}" title="${s("accountColor")}" aria-label="${s("accountColor")}" />
          <span class="badge provider-${e.provider}">${n(o.label)}</span>
          <input class="input account-label" data-field="label" value="${n(e.label)}" placeholder="${s("labelPlaceholder")}" />
        </div>
        <div class="account-head-actions">
          <label class="check-row">
            <input type="checkbox" data-field="enabled"${e.enabled?" checked":""} /> ${s("enabled")}
          </label>
          <button type="button" class="btn btn-sm" data-remove="${n(e.id)}">${s("remove")}</button>
        </div>
      </div>
      ${l}
      <p class="hint">
        <a href="${n(o.tokenDocsUrl)}" target="_blank" rel="noopener">${s("tokenHowTo")}</a>
      </p>
      <div class="account-filters">
        <label class="field-label">
          ${s("scope")}
          <select class="select" data-field="scope">${c}</select>
        </label>
        <div>
          <p class="hint">${s("statesLabel")}</p>
          <div class="checks">${p}</div>
        </div>
      </div>
    </div>`}function m(){return Array.from(v.querySelectorAll(".account-card")).map(o=>{var f,y;const l=o.dataset.id??"",c=r.find(i=>i.id===l),p=(c==null?void 0:c.provider)??"gitlab",t=i=>{var k;return((k=o.querySelector(`[data-field="${i}"]`))==null?void 0:k.value.trim())??""},u=Array.from(o.querySelectorAll("input[data-state]:checked")).map(i=>i.dataset.state);return{id:l,provider:p,label:t("label")||p,host:t("host"),token:t("token"),username:t("username"),workspace:t("workspace"),scope:((f=o.querySelector('[data-field="scope"]'))==null?void 0:f.value)??"assigned_to_me",states:u.length?u:["open"],enabled:((y=o.querySelector('[data-field="enabled"]'))==null?void 0:y.checked)??!0,color:t("color")||(c==null?void 0:c.color)||"#e8590c"}})}T.addEventListener("click",()=>{const e=x.value;r=m(),r.push(E(e,g(e).label,r.length)),b()});v.addEventListener("click",e=>{const l=e.target.dataset.remove;l&&(r=m().filter(c=>c.id!==l),b())});I.addEventListener("submit",e=>{e.preventDefault(),H()});async function H(){d.textContent=s("saving"),d.classList.remove("error");const e=m(),o=e.find(c=>c.enabled&&!c.token);if(o){d.textContent=s("needsToken",o.label),d.classList.add("error");return}const l=await S(e);if(await $({accounts:e,syncIntervalMinutes:Number(a("syncIntervalMinutes").value),notifyOn:{newMr:a("notifyNewMr").checked,statusChange:a("notifyStatusChange").checked,newComment:!1},display:{themeControls:a("dispThemeControls").checked,filters:a("dispFilters").checked,sort:a("dispSort").checked,openAll:a("dispOpenAll").checked,credit:a("dispCredit").checked}}),r=e,await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!l){d.textContent=s("hostAccessDenied"),d.classList.add("error");return}d.textContent=s("saved"),setTimeout(()=>{d.textContent=""},3e3)}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}j();
//# sourceMappingURL=options.html-CnwuNC51.js.map
