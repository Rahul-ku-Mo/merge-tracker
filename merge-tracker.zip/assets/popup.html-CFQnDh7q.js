import{e as de,a as l,h as ue,i as pe,d as G}from"./permissions-D7RsSpsT.js";import{t as o,b as _,g as I,d as fe,e as B,a as me,f as ge,h as he,i as be,j as Z,k as ye,c as ve}from"./registry-CixNjWm-.js";const we={github:'<path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0 1 12 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222 0 1.606-.014 2.898-.014 3.293 0 .322.216.694.825.576C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>',gitlab:'<path d="m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.462-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z"/>',bitbucket:'<path d="M.778 1.213a.768.768 0 0 0-.768.892l3.263 19.81c.084.5.515.868 1.022.873H19.95a.772.772 0 0 0 .77-.646l3.27-20.03a.768.768 0 0 0-.768-.891zM14.52 15.53H9.522L8.17 8.466h7.561z"/>'};function P(e,t=""){return`<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"${t?` class="${t}"`:""}>${we[e]}</svg>`}const Se=["github","gitlab","bitbucket"],$e={github:{scopes:["repo","read:user"],note:o("connectNoteGithub"),tokenPlaceholder:"github_pat_… or ghp_…"},gitlab:{scopes:["read_api"],note:o("connectNoteGitlab"),tokenPlaceholder:"glpat-xxxxxxxxxxxxxx"},bitbucket:{scopes:["pullrequest:read"],note:o("connectNoteBitbucket"),tokenPlaceholder:"App password"}};function ke(e){const t=document.getElementById("connect-panel");if(!t)throw new Error("connect-panel element missing");const n=t.querySelector("#connect-list"),s=t.querySelector("#connect-form-wrap"),c=t.querySelector("#connect-form"),a=t.querySelector("#connect-back"),b=t.querySelector("#connect-error");if(!n||!s||!c||!a||!b)throw new Error("connect panel elements missing");let v=null;function S(r){b.textContent=r,b.hidden=!r}function $(){v=null,s.hidden=!0,n.hidden=!1,S(""),n.replaceChildren();for(const r of Se){const d=_(r),u=document.createElement("button");u.type="button",u.className="connect-card",u.dataset.provider=r,u.innerHTML=`
        <span class="connect-card-icon badge provider-${r}">${P(r)}</span>
        <span class="connect-card-body">
          <span class="connect-card-name">${f(d.label)}</span>
          <span class="connect-card-status">${o("connectNotConnected")}</span>
        </span>
        <span class="connect-card-action">${o("connectAction")}</span>
      `,u.addEventListener("click",()=>q(r)),n.appendChild(u)}}function q(r){var V;v=r,S(""),n.hidden=!0,s.hidden=!1;const d=_(r),u=$e[r],D=d.fields.find(p=>p.key==="token"),re=d.fields.filter(p=>p.key!=="token"),ie=u.scopes.map(p=>`<span class="connect-scope">${f(p)}</span>`).join(""),le=re.map(p=>`
        <label class="connect-field">
          <span class="connect-field-label">${f(p.label)}${p.required?" *":""}</span>
          <input
            class="input"
            type="text"
            name="${p.key}"
            autocomplete="off"
            placeholder="${f(p.placeholder)}"
            ${p.required?"required":""}
          />
          ${p.hint?`<span class="connect-field-hint">${f(p.hint)}</span>`:""}
        </label>`).join("");c.innerHTML=`
      <div class="connect-form-head">
        <span class="connect-form-icon badge provider-${r}">${P(r)}</span>
        <div class="connect-form-title">
          <strong>${f(d.label)}</strong>
          <span>${o("connectNotConnected")}</span>
        </div>
      </div>
      ${le}
      <label class="connect-field">
        <span class="connect-field-label">${f((D==null?void 0:D.label)??o("connectTokenLabel"))} *</span>
        <input
          class="input"
          type="password"
          name="token"
          autocomplete="off"
          placeholder="${f(u.tokenPlaceholder)}"
          required
        />
      </label>
      <a class="connect-docs" href="${f(d.tokenDocsUrl)}" target="_blank" rel="noopener">
        ${o("connectDocs")}
      </a>
      <div class="connect-scopes card">
        <p class="connect-scopes-title">${o("connectScopesTitle")}</p>
        <div class="connect-scopes-tags">${ie}</div>
        <p class="connect-scopes-note">${f(u.note)}</p>
      </div>
      <button type="submit" class="btn btn-primary connect-submit">${f(o("connectSubmit",d.label))}</button>
    `,(V=c.querySelector('input[name="token"]'))==null||V.focus()}return a.addEventListener("click",()=>$()),c.addEventListener("submit",r=>{r.preventDefault(),v&&Ce(v,c,S,e)}),$(),{root:t,show:()=>{t.hidden=!1,$()},hide:()=>{t.hidden=!0,S("")}}}async function Ce(e,t,n,s){n("");const c=t.querySelector(".connect-submit");c&&(c.disabled=!0);try{const a=new FormData(t),b=String(a.get("token")??"").trim();if(!b){n(o("connectTokenRequired"));return}const v=_(e),S=await I(),$=fe(e,v.label,S.accounts.length);for(const d of v.fields){if(d.key==="token"){$.token=b;continue}const u=String(a.get(d.key)??"").trim();if(d.required&&!u){n(o("connectFieldRequired",d.label));return}$[d.key]=u}const q=[...S.accounts,$],r=await de(q);if(await B({accounts:q}),await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!r){n(o("hostAccessDenied"));return}s()}catch(a){const b=a instanceof Error?a.message:String(a);n(b)}finally{c&&(c.disabled=!1)}}function f(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const m=l("status"),H=l("controls"),x=l("filter-project"),R=l("filter-state"),L=l("sort-btn"),ee=l("open-all-btn"),O=l("muted-bar"),Ee=l("muted-text"),Le=l("unmute-btn"),g=l("mr-list"),T=l("empty-state"),W=T.querySelector(".empty-title"),Y=T.querySelector(".empty-desc"),M=l("sync-btn"),te=l("last-sync"),xe=l("options-link");let E=[],i,w,h=new Set;const A=new Map;let ne=!0,k=null;xe.addEventListener("click",e=>{e.preventDefault(),chrome.runtime.openOptionsPage()});M.addEventListener("click",()=>void ae(!0));async function Me(){ge(),ue(),i=await he(),w=await be(),R.value=i.state,ce(),He();const e=await I();pe({toggleId:"mode-toggle",mode:e.mode,onChange:n=>void B({mode:n})}),A.clear();for(const n of e.accounts)A.set(n.id,{color:n.color,label:n.label});if(h=new Set(e.mutedRepos),Te(e.display),k=ke(()=>void J()),!e.accounts.some(n=>n.enabled&&n.token.trim())){Ae();return}await J()}async function J(){k==null||k.hide(),m.hidden=!1,M.hidden=!1;const e=await I();A.clear();for(const t of e.accounts)A.set(t.id,{color:t.color,label:t.label});h=new Set(e.mutedRepos),await F(),await ae(!1)}function Ae(){m.hidden=!0,H.hidden=!0,g.hidden=!0,T.hidden=!0,O.hidden=!0,M.hidden=!0,te.textContent="",k==null||k.show()}function Te(e){var n;((s,c)=>{const a=document.getElementById(s);a&&(a.hidden=c)})("mode-toggle",!e.themeControls),x.hidden=!e.filters,R.hidden=!e.filters,L.hidden=!e.sort,ee.hidden=!e.openAll,(n=document.querySelector(".credit"))==null||n.toggleAttribute("hidden",!e.credit),ne=e.filters||e.sort||e.openAll}async function F(){const{mergeRequests:e,lastSyncAt:t}=await me();E=e,z(),N(),U(),te.textContent=t?o("syncedAt",Ve(t)):""}function z(){const e=[...new Set(E.filter(s=>!h.has(s.repo)).map(s=>s.repo))].sort((s,c)=>s.localeCompare(c)),t=[{value:"all",label:o("filterAllProjects")},...e.map(s=>({value:s,label:s}))];t.some(s=>s.value===i.project)||(i.project="all"),x.replaceChildren();for(const s of t){const c=document.createElement("option");c.value=s.value,c.textContent=s.label,x.appendChild(c)}x.value=i.project}function N(){if(Pe(),!E.length){H.hidden=!0,g.hidden=!0,X(o("emptyNoMrTitle"),o("emptyNoMrDesc")),C(o("statusNoMr"),"default");return}H.hidden=!ne;const e=E.filter(s=>!h.has(s.repo)),t=oe(e.filter(se));if(!t.length){g.hidden=!0,X(o("emptyNoMatchesTitle"),o("emptyNoMatchesDesc")),C(o("statusShown",["0",String(e.length)]),"default");return}T.hidden=!0,Re(qe(t)),g.hidden=!1;const n=t.length===e.length?e.length===1?o("requestsOne"):o("requestsMany",String(e.length)):o("statusShown",[String(t.length),String(e.length)]);C(n,"success"),_e()}function se(e){return!(i.project!=="all"&&e.repo!==i.project||i.state!=="all"&&e.state!==i.state)}function oe(e){const t=i.sort==="updated_asc"?1:-1;return[...e].sort((n,s)=>t*(new Date(n.updatedAt).getTime()-new Date(s.updatedAt).getTime()))}function qe(e){const t=new Map;for(const n of e){const s=t.get(n.repo)??[];s.push(n),t.set(n.repo,s)}return[...t.entries()].map(([n,s])=>({repo:n,items:s}))}function Re(e){var s;const t=Be(),n=g.scrollTop;g.replaceChildren();for(const c of e){const a=document.createElement("div");a.className="mr-group",a.innerHTML=`
      <div class="mr-group-header">
        <span class="mr-group-name">${y(c.repo)}</span>
        <span class="mr-group-count">${c.items.length}</span>
      </div>
      <ul class="mr-group-list">${c.items.map(Ne).join("")}</ul>
    `,g.appendChild(a)}g.scrollTop=n,t&&((s=g.querySelector(t))==null||s.focus())}function Be(){const e=document.activeElement;if(!(e instanceof HTMLElement)||!g.contains(e))return null;const{key:t,copy:n,mute:s}=e.dataset;return t?`.mr-title[data-key="${CSS.escape(t)}"]`:n?`[data-copy="${CSS.escape(n)}"]`:s?`[data-mute="${CSS.escape(s)}"]`:null}function Ne(e){const t=A.get(e.accountId),n=(t==null?void 0:t.color)??"#888",s=o("copyLink"),c=o("muteProject"),a=je(e),b=w.opened.includes(e.key);return`
    <li class="${["mr-item",a?"is-new":"",b?"is-read":""].filter(Boolean).join(" ")}">
      <div class="mr-row">
        <span class="acct-dot" style="background:${y(n)}" title="${y((t==null?void 0:t.label)??"")}" aria-label="${y(o("accountLabel",(t==null?void 0:t.label)??""))}" role="img"></span>
        <a class="mr-title" href="${y(e.url)}" data-key="${y(e.key)}" target="_blank" rel="noopener">${y(e.title)}</a>
        <span class="mr-actions">
          <button class="mr-action" type="button" data-copy="${y(e.url)}" title="${s}" aria-label="${s}">
            ${G("copy",13)}
          </button>
          <button class="mr-action" type="button" data-mute="${y(e.repo)}" title="${c}" aria-label="${c}">
            ${G("eye-off",13)}
          </button>
        </span>
      </div>
      <span class="mr-meta">
        ${De(e.provider)}
        <span class="badge ${e.state}">${ve(e.state)}</span>
        ${e.draft?`<span class="badge draft">${o("draft")}</span>`:""}
        <span class="mr-meta-sep">·</span>
        <span>#${e.number}</span>
        <span class="mr-meta-sep">·</span>
        <span>${y(e.author)}</span>
      </span>
    </li>
  `}function De(e){const t=P(e);return`<span class="badge provider-${e} mr-provider" title="${e}">${t}</span>`}function je(e){const t=w.seen[e.key];return t?new Date(e.updatedAt).getTime()>new Date(t).getTime():!0}function _e(){for(const e of E)w.seen[e.key]=e.updatedAt;Z(w)}function Pe(){if(!h.size){O.hidden=!0;return}O.hidden=!1;const e=h.size;Ee.textContent=e===1?o("mutedOne"):o("mutedMany",String(e))}async function U(){const e=E.filter(t=>t.state==="open"&&!h.has(t.repo)).length;await chrome.action.setBadgeBackgroundColor({color:"#0965ce"}),await chrome.action.setBadgeText({text:e>0?String(e):""})}function He(){x.addEventListener("change",()=>{i.project=x.value,j()}),R.addEventListener("change",()=>{i.state=R.value,j()}),L.addEventListener("click",()=>{i.sort=i.sort==="updated_desc"?"updated_asc":"updated_desc",ce(),j()}),ee.addEventListener("click",()=>Oe()),Le.addEventListener("click",()=>void ze()),g.addEventListener("click",e=>{const t=e.target,n=t.closest("[data-copy]");if(n){Fe(n.dataset.copy??"");return}const s=t.closest("[data-mute]");if(s){Ie(s.dataset.mute??"");return}const c=t.closest(".mr-title");c!=null&&c.dataset.key&&Ue(c.dataset.key)})}function ce(){const e=i.sort==="updated_asc";L.classList.toggle("is-asc",e),L.title=e?o("sortOldest"):o("sortNewest"),L.setAttribute("aria-label",L.title)}function Oe(){const e=oe(E.filter(t=>!h.has(t.repo)).filter(se));for(const t of e)t.url&&chrome.tabs.create({url:t.url,active:!1})}async function Fe(e){if(e)try{await navigator.clipboard.writeText(e),Q(o("linkCopied"))}catch{Q(o("copyFailed"))}}async function Ie(e){e&&(h.add(e),await B({mutedRepos:[...h]}),z(),N(),U())}async function ze(){h.clear(),await B({mutedRepos:[]}),z(),N(),U()}function Ue(e){w.opened.includes(e)||(w.opened.push(e),Z(w))}async function j(){N(),await ye(i)}async function ae(e){M.disabled=!0,C(o("syncing"),"loading");try{const t=await chrome.runtime.sendMessage({type:"SYNC_NOW"});if(!(t!=null&&t.ok))throw new Error((t==null?void 0:t.error)??o("syncFailed"));await F(),t.errors.length&&C(o("statusFailed",[String(t.count),String(t.errors.length)]),"error")}catch(t){if(e){const n=t instanceof Error?t.message:String(t);C(n,"error")}else await F()}finally{M.disabled=!1}}function C(e,t="default"){m.textContent=e,m.hidden=!1,m.classList.remove("is-error","is-success","is-loading","is-info"),t==="error"&&m.classList.add("is-error"),t==="success"&&m.classList.add("is-success"),t==="loading"&&m.classList.add("is-loading"),t==="info"&&m.classList.add("is-info")}let K;function Q(e){const t=m.textContent??"";C(e,"success"),window.clearTimeout(K),K=window.setTimeout(()=>{m.textContent=t},1500)}function X(e,t){W&&(W.textContent=e),Y&&(Y.textContent=t),T.hidden=!1}function Ve(e){const t=Date.now()-new Date(e).getTime(),n=Math.floor(t/6e4);if(n<1)return o("justNow");if(n<60)return o("minutesAgo",String(n));const s=Math.floor(n/60);return s<24?o("hoursAgo",String(s)):new Date(e).toLocaleString()}function y(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}Me();
//# sourceMappingURL=popup.html-CFQnDh7q.js.map
