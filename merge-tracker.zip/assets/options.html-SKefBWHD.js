import{r as E,a as b,b as m,e as A,c as t,n as R,h as M,i as L,p as N}from"./permissions-CmyJLY3W.js";import{t as c,f as O,g as y,h as q,n as T,i as _,a as I,e as H,R as D}from"./registry-CbYly80v.js";const x=E("config-form"),v=b("accounts"),F=b("accounts-empty"),B=b("add-account"),U=m("new-provider"),u=b("save-status"),j=[{value:"assigned_to_me",label:c("scopeAssigned")},{value:"created_by_me",label:c("scopeCreated")},{value:"needs_my_review",label:c("scopeReview")},{value:"all",label:c("scopeAll")}],P=["open","merged","closed"];let r=[];async function W(){_(),M();const e=await I();L({toggleId:"mode-toggle",mode:e.mode,onChange:s=>void q({mode:s})}),r=e.accounts,t("syncIntervalMinutes").value=String(e.syncIntervalMinutes),t("notifyNewMr").checked=e.notifyOn.newMr,t("notifyStatusChange").checked=e.notifyOn.statusChange,t("notifyReviewRequested").checked=e.notifyOn.reviewRequested,t("notifyCiFailed").checked=e.notifyOn.ciFailed,t("notifyDigest").checked=e.digestNotifications,t("quietEnabled").checked=e.quietHours.enabled,t("ticketBaseUrl").value=e.ticketBaseUrl,t("quietStart").value=String(e.quietHours.start),t("quietEnd").value=String(e.quietHours.end),t("dispThemeControls").checked=e.display.themeControls,t("dispFilters").checked=e.display.filters,t("dispSort").checked=e.display.sort,t("dispOpenAll").checked=e.display.openAll,t("dispCredit").checked=e.display.credit,z(e.recentRetentionDays),g()}function z(e){m("recentRetention").replaceChildren(...D.map(n=>{const o=document.createElement("option");return o.value=String(n),o.textContent=n===1?c("dayOne"):c("daysMany",String(n)),o.selected=n===e,o}))}function g(){F.hidden=r.length>0,v.replaceChildren();for(const e of r)v.insertAdjacentHTML("beforeend",Y(e));v.querySelectorAll(".account-card").forEach(e=>{w(e)})}function k(e,s){return['<option value="">N/A</option>',...(s&&!e.includes(s)?[s,...e]:e).map(l=>`<option value="${i(l)}"${l===s?" selected":""}>${i(l)}</option>`)].join("")}async function w(e){var h,f;const s=y(e.dataset.provider),n=e.querySelector('select[data-field="workspace"]'),o=e.querySelector(".org-status"),l=((h=e.querySelector('[data-field="token"]'))==null?void 0:h.value.trim())??"",a=((f=e.querySelector('[data-field="host"]'))==null?void 0:f.value.trim())??"";if(!n||!s.listWorkspaces||!l)return;const d=n.value;n.disabled=!0;try{const p=await s.listWorkspaces(l,a);n.innerHTML=k(p,d),o&&(o.textContent="")}catch{n.innerHTML=k([],d),o&&(o.textContent=c("orgLoadFailed"))}finally{n.disabled=!1}}v.addEventListener("change",e=>{const s=e.target;if(s.dataset.field==="token"||s.dataset.field==="host"){const n=s.closest(".account-card");n&&w(n)}});function Y(e){const s=y(e.provider),n=s.fields.map(a=>{const d=e[a.key]??"";return a.kind==="select"?`
        <label class="field-label">
          ${a.label}
          <select class="select" data-field="${a.key}">${k([],d)}</select>
          <span class="hint org-status"></span>
          ${a.hint?`<span class="hint">${i(a.hint)}</span>`:""}
        </label>`:`
        <label class="field-label">
          ${a.label}${a.required?" *":""}
          <input
            class="input"
            type="${a.secret?"password":"text"}"
            data-field="${a.key}"
            autocomplete="off"
            placeholder="${i(a.placeholder)}"
            value="${i(d)}"
          />
          ${a.hint?`<span class="hint">${i(a.hint)}</span>`:""}
        </label>`}).join(""),o=j.map(a=>`<option value="${a.value}"${e.scope===a.value?" selected":""}>${a.label}</option>`).join(""),l=P.map(a=>`
      <label class="check-row">
        <input type="checkbox" data-state="${a}"${e.states.includes(a)?" checked":""} />
        ${H(a)}
      </label>`).join("");return`
    <div class="account-card card" data-id="${i(e.id)}" data-provider="${e.provider}">
      <div class="account-head">
        <div class="account-title">
          <span class="badge provider-${e.provider}" title="${i(s.label)}">${N(e.provider)}</span>
          <input class="input account-label" data-field="label" value="${i(e.label)}" placeholder="${c("labelPlaceholder")}" />
        </div>
        <div class="account-head-actions">
          <label class="check-row">
            <input type="checkbox" data-field="enabled"${e.enabled?" checked":""} /> ${c("enabled")}
          </label>
          <button type="button" class="btn btn-sm" data-remove="${i(e.id)}">${c("remove")}</button>
        </div>
      </div>
      ${n}
      <p class="hint">
        <a href="${i(s.tokenDocsUrl)}" target="_blank" rel="noopener">${c("tokenHowTo")}</a>
      </p>
      <div class="account-filters">
        <label class="field-label">
          ${c("scope")}
          <select class="select" data-field="scope">${o}</select>
        </label>
        <div>
          <p class="hint">${c("statesLabel")}</p>
          <div class="checks">${l}</div>
        </div>
      </div>
    </div>`}function $(){return Array.from(v.querySelectorAll(".account-card")).map(s=>{var h,f;const n=s.dataset.id??"",o=r.find(p=>p.id===n),l=(o==null?void 0:o.provider)??"gitlab",a=p=>{var C;return((C=s.querySelector(`[data-field="${p}"]`))==null?void 0:C.value.trim())??""},d=Array.from(s.querySelectorAll("input[data-state]:checked")).map(p=>p.dataset.state);return{id:n,provider:l,label:a("label")||l,host:a("host"),token:a("token"),username:a("username"),workspace:a("workspace"),scope:((h=s.querySelector('[data-field="scope"]'))==null?void 0:h.value)??"assigned_to_me",states:d.length?d:["open"],enabled:((f=s.querySelector('[data-field="enabled"]'))==null?void 0:f.checked)??!0,color:(o==null?void 0:o.color)||"#e8590c"}})}B.addEventListener("click",()=>{const e=U.value;r=$(),r.push(O(e,y(e).label,r.length)),g()});v.addEventListener("click",e=>{const n=e.target.dataset.remove;n&&(r=$().filter(o=>o.id!==n),g())});x.addEventListener("submit",e=>{e.preventDefault(),G()});async function G(){u.textContent=c("saving"),u.classList.remove("error");const e=$(),s=e.find(o=>o.enabled&&!o.token);if(s){u.textContent=c("needsToken",s.label),u.classList.add("error");return}const n=await A(e);if(await q({accounts:e,syncIntervalMinutes:Number(t("syncIntervalMinutes").value),notifyOn:{newMr:t("notifyNewMr").checked,statusChange:t("notifyStatusChange").checked,newComment:!1,reviewRequested:t("notifyReviewRequested").checked,ciFailed:t("notifyCiFailed").checked},digestNotifications:t("notifyDigest").checked,ticketBaseUrl:R(t("ticketBaseUrl").value),quietHours:{enabled:t("quietEnabled").checked,start:S(Number(t("quietStart").value)),end:S(Number(t("quietEnd").value))},display:{themeControls:t("dispThemeControls").checked,filters:t("dispFilters").checked,sort:t("dispSort").checked,openAll:t("dispOpenAll").checked,credit:t("dispCredit").checked},recentRetentionDays:T(Number(m("recentRetention").value))}),r=e,await chrome.runtime.sendMessage({type:"RESCHEDULE_ALARM"}),await chrome.runtime.sendMessage({type:"SYNC_NOW"}),!n){u.textContent=c("hostAccessDenied"),u.classList.add("error");return}u.textContent=c("saved"),setTimeout(()=>{u.textContent=""},3e3)}function i(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}W();function S(e){return Number.isInteger(e)&&e>=0&&e<=23?e:0}
//# sourceMappingURL=options.html-SKefBWHD.js.map
