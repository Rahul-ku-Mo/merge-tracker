import './assets/service-worker.ts-CvvlWGmO.js';
